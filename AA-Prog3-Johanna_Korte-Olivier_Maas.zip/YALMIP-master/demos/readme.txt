For demos, please see the extensive on-line manual
http://users.isy.liu.se/johanl/yalmip