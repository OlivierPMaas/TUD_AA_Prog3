function YESNO = isreal(F)
%ISREAL (overloaded)

YESNO = isreal(lmi(F));