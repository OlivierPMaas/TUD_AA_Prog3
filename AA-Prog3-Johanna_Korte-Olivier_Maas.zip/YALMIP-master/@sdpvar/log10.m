function varargout = log10(varargin)
%log10 (overloaded)

varargout{1} = log(varargin{1})/log(10);