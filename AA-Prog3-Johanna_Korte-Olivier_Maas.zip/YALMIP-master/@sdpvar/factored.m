function YESNO = factored(X)

YESNO = ~isempty(X.midfactors);
